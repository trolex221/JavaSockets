package practica1AAX;

public class UseServerHub {

	public static void main(String[] args) {
		ServerHub objetoServer = new ServerHub(4444);
		objetoServer.run();

	}

}
